package com.example.inventoryappbeccadaniel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Database helper
    private DBHelper dbHelper;

    // UI fields
    private EditText itemNameEditText;
    private EditText quantityEditText;
    private EditText itemIdEditText;
    private Button addButton;
    private Button updateButton;
    private Button deleteButton;
    private Button refreshButton;
    private EditText searchEditText;
    private Button searchButton;
    private GridView gridView;

    // Data for GridView
    private final List<Map<String, String>> dataList = new ArrayList<>();     // full data from DB
    private final List<Map<String, String>> displayList = new ArrayList<>();  // what user sees (full or filtered)
    private SimpleAdapter adapter;

    private final String[] from = {"id", "name", "quantity"};
    private final int[] to = {R.id.itemId, R.id.itemName, R.id.itemQuantity};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_activity);

        setupDatabase();
        initializeViews();

        // Set adapter ONCE
        adapter = new SimpleAdapter(
                this,
                displayList,
                R.layout.inventory_item,
                from,
                to
        );
        gridView.setAdapter(adapter);

        setupListeners();
        loadGridView();
    }

    private void setupDatabase() {
        dbHelper = new DBHelper(this);
    }

    private void initializeViews() {
        itemNameEditText = findViewById(R.id.nameEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        itemIdEditText = findViewById(R.id.idEditText);

        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        refreshButton = findViewById(R.id.refreshButton);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);

        gridView = findViewById(R.id.gridView);
    }

    private void setupListeners() {
        addButton.setOnClickListener(v -> handleAdd());
        updateButton.setOnClickListener(v -> handleUpdate());
        deleteButton.setOnClickListener(v -> handleDelete());

        refreshButton.setOnClickListener(v -> {
            searchEditText.setText(""); // optional: clear search on refresh
            loadGridView();
        });

        searchButton.setOnClickListener(v -> {
            String query = searchEditText.getText().toString().trim();
            if (query.isEmpty()) {
                showFullList(); // reset to full list
            } else {
                filterInventory(query); // apply algorithm
            }
        });
    }

    private void handleAdd() {
        String name = itemNameEditText.getText().toString();
        String qtyText = quantityEditText.getText().toString();

        if (isBlank(name) || isBlank(qtyText)) {
            toast("Please enter name and quantity.");
            return;
        }

        Integer qty = tryParseInt(qtyText);
        if (qty == null || qty < 0) {
            toast("Quantity must be a whole number 0 or higher.");
            return;
        }

        boolean inserted = dbHelper.insertItem(name.trim(), qty);
        if (inserted) {
            toast("Item added!");
            clearInputs();
            loadGridView();
        } else {
            toast("Failed to add item.");
        }
    }

    private void handleUpdate() {
        String idText = itemIdEditText.getText().toString();
        String name = itemNameEditText.getText().toString();
        String qtyText = quantityEditText.getText().toString();

        if (isBlank(idText) || isBlank(name) || isBlank(qtyText)) {
            toast("Enter ID, name, and quantity to update.");
            return;
        }

        Integer id = tryParseInt(idText);
        Integer qty = tryParseInt(qtyText);

        if (id == null || id < 0 || qty == null || qty < 0) {
            toast("ID and quantity must be valid whole numbers.");
            return;
        }

        boolean updated = dbHelper.updateItem(id, name.trim(), qty);
        if (updated) {
            toast("Item updated!");
            clearInputs();
            loadGridView();
        } else {
            toast("Failed to update item.");
        }
    }

    private void handleDelete() {
        String idText = itemIdEditText.getText().toString();

        if (isBlank(idText)) {
            toast("Enter an ID to delete.");
            return;
        }

        Integer id = tryParseInt(idText);
        if (id == null || id < 0) {
            toast("ID must be a valid whole number.");
            return;
        }

        boolean deleted = dbHelper.deleteItem(id);
        if (deleted) {
            toast("Item deleted!");
            clearInputs();
            loadGridView();
        } else {
            toast("Failed to delete item.");
        }
    }

    /**
     * Filters inventory items by name using a simple linear search.
     * This demonstrates an algorithms/data structures enhancement using lists and iteration.
     */
    private void filterInventory(String query) {
        displayList.clear();

        for (Map<String, String> item : dataList) {
            String name = item.get("name");
            if (name != null && name.toLowerCase().contains(query.toLowerCase())) {
                displayList.add(item);
            }
        }

        adapter.notifyDataSetChanged();
    }

    /**
     * Loads all inventory items from the database and updates the GridView.
     */
    private void loadGridView() {
        dataList.clear();
        displayList.clear();

        var cursor = dbHelper.getAllItems();
        if (cursor == null) {
            toast("Error loading items.");
            return;
        }

        try {
            if (cursor.moveToFirst()) {
                int idCol = cursor.getColumnIndexOrThrow("id");
                int nameCol = cursor.getColumnIndexOrThrow("name");
                int qtyCol = cursor.getColumnIndexOrThrow("quantity");

                do {
                    Map<String, String> map = new HashMap<>();
                    map.put("id", cursor.getString(idCol));
                    map.put("name", cursor.getString(nameCol));
                    map.put("quantity", cursor.getString(qtyCol));
                    dataList.add(map);
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        // Show full list by default
        showFullList();
    }
    private void showFullList() {
        displayList.clear();
        displayList.addAll(dataList);
        adapter.notifyDataSetChanged();
    }

    private Integer tryParseInt(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception e) {
            return null;
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private void clearInputs() {
        itemIdEditText.setText("");
        itemNameEditText.setText("");
        quantityEditText.setText("");
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
