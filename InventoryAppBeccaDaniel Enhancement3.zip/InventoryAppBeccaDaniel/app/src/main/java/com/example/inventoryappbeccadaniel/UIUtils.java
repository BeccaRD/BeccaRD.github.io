package com.example.inventoryappbeccadaniel;

import android.content.Context;
import android.widget.Toast;
public class UIUtils {

    public static void showMessage(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
