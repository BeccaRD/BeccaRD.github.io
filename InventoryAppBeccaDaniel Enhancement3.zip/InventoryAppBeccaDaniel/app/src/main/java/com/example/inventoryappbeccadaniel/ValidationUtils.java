package com.example.inventoryappbeccadaniel;

import android.text.TextUtils;
public class ValidationUtils {
    public static boolean isFieldEmpty(String value) {
        return TextUtils.isEmpty(value) || value.trim().isEmpty();
    }

    public static boolean isValidQuantity(String quantity) {
        if (isFieldEmpty(quantity)) return false;
        try {
            int q = Integer.parseInt(quantity);
            return q >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
