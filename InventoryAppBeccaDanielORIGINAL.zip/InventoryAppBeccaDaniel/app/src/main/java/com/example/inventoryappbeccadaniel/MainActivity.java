package com.example.inventoryappbeccadaniel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;

    EditText itemNameEditText, quantityEditText, itemIdEditText;
    Button addButton, updateButton, deleteButton;
    GridView gridView;

    List<Map<String, String>> dataList = new ArrayList<>();
    String[] from = {"id", "name", "quantity"};
    int[] to = {R.id.itemId, R.id.itemName, R.id.itemQuantity};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_activity);

        dbHelper = new DBHelper(this);

        itemNameEditText = findViewById(R.id.nameEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        itemIdEditText = findViewById(R.id.idEditText);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        gridView = findViewById(R.id.gridView);

        loadGridView();

        addButton.setOnClickListener(v -> {
            String name = itemNameEditText.getText().toString().trim();
            String qtyText = quantityEditText.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Please enter name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty = Integer.parseInt(qtyText);

            boolean inserted = dbHelper.insertItem(name, qty);
            if (inserted) {
                Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                itemNameEditText.setText("");
                quantityEditText.setText("");
                loadGridView();
            } else {
                Toast.makeText(this, "Failed to add item.", Toast.LENGTH_SHORT).show();
            }
        });

        updateButton.setOnClickListener(v -> {
            String idText = itemIdEditText.getText().toString().trim();
            String name = itemNameEditText.getText().toString().trim();
            String qtyText = quantityEditText.getText().toString().trim();

            if (idText.isEmpty() || name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Enter ID, name, and quantity to update", Toast.LENGTH_SHORT).show();
                return;
            }

            int id = Integer.parseInt(idText);
            int qty = Integer.parseInt(qtyText);

            boolean updated = dbHelper.updateItem(id, name, qty);
            if (updated) {
                Toast.makeText(this, "Item updated!", Toast.LENGTH_SHORT).show();
                loadGridView();
            } else {
                Toast.makeText(this, "Failed to update item.", Toast.LENGTH_SHORT).show();
            }
        });

        deleteButton.setOnClickListener(v -> {
            String idText = itemIdEditText.getText().toString().trim();
            if (idText.isEmpty()) {
                Toast.makeText(this, "Enter ID to delete", Toast.LENGTH_SHORT).show();
                return;
            }

            int id = Integer.parseInt(idText);

            boolean deleted = dbHelper.deleteItem(id);
            if (deleted) {
                Toast.makeText(this, "Item deleted!", Toast.LENGTH_SHORT).show();
                loadGridView();
            } else {
                Toast.makeText(this, "Failed to delete item.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadGridView() {
        dataList.clear();
        var cursor = dbHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                Map<String, String> map = new HashMap<>();
                map.put("id", cursor.getString(cursor.getColumnIndexOrThrow("id")));
                map.put("name", cursor.getString(cursor.getColumnIndexOrThrow("name")));
                map.put("quantity", cursor.getString(cursor.getColumnIndexOrThrow("quantity")));
                dataList.add(map);
            } while (cursor.moveToNext());
        }
        cursor.close();

        SimpleAdapter adapter = new SimpleAdapter(
                this,
                dataList,
                R.layout.inventory_item,
                from,
                to
        );
        gridView.setAdapter(adapter);
    }
}
